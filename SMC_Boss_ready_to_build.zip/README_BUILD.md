SMC Boss Android
================

Project ini sudah disiapkan untuk dibuat menjadi APK.

Cara paling mudah:
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini.
3. Buka tab Actions.
4. Jalankan workflow "Build SMC Boss APK" dengan tombol "Run workflow".
5. Setelah selesai, buka hasil run -> Artifacts -> SMC-Boss-debug.
6. Download app-debug.apk ke HP dan instal.

Catatan:
- Ini adalah APK debug untuk penggunaan pribadi.
- Fitur yang ada: checklist SMC, pengingat, notifikasi, suara Bahasa Indonesia, dan tombol video SMC M5.
