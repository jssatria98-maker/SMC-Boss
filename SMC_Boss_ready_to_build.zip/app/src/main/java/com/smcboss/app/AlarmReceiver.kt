package com.smcboss.app

import android.app.*
import android.content.*
import android.os.Build
import java.util.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("smc", "SMC Boss", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)
        }

        val n = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(c, "smc")
        } else {
            Notification.Builder(c)
        }.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("SMC Boss")
            .setContentText("Boss, bangun. Waktunya belajar SMC dan scalping M5.")
            .setAutoCancel(true)
            .build()

        nm.notify(123, n)

        val tts = android.speech.tts.TextToSpeech(c) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                tts.language = Locale("id", "ID")
                tts.speak(
                    "Boss, bangun. Waktunya belajar SMC dan scalping M5.",
                    android.speech.tts.TextToSpeech.QUEUE_FLUSH,
                    null,
                    "alarm"
                )
            }
        }
    }
}
