package com.smcboss.app

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private var tts: android.speech.tts.TextToSpeech? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
        }

        val title = TextView(this).apply {
            text = "👑 SMC Boss"
            textSize = 30f
        }
        val info = TextView(this).apply {
            text = "Belajar Smart Money Concepts • Scalping M5\n\nLiquidity → Sweep → MSS/CHoCH → OB/FVG → Entry → SL/TP"
            textSize = 18f
        }
        val time = TimePicker(this).apply {
            setIs24HourView(true)
            hour = 8
            minute = 0
        }
        val set = Button(this).apply { text = "⏰ Pasang Pengingat" }
        val test = Button(this).apply { text = "🔊 Tes Suara" }
        val video = Button(this).apply { text = "🎥 Buka Video SMC M5" }
        val checklist = TextView(this).apply {
            text = "\n✅ Checklist Entry\n☐ Liquidity jelas\n☐ Sweep terjadi\n☐ MSS/CHoCH valid\n☐ OB/FVG valid\n☐ SL & TP sudah ditentukan"
            textSize = 18f
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(time)
        layout.addView(set)
        layout.addView(test)
        layout.addView(video)
        layout.addView(checklist)
        setContentView(layout)

        test.setOnClickListener {
            speak("Boss, ini tes suara SMC Boss. Waktunya belajar Smart Money Concepts.")
        }

        set.setOnClickListener {
            schedule(time.hour, time.minute)
            Toast.makeText(this, "Pengingat dipasang.", Toast.LENGTH_SHORT).show()
        }

        video.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("https://www.youtube.com/watch?v=2bjXi-bINuo")))
        }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
        }
    }

    private fun speak(s: String) {
        tts?.shutdown()
        tts = android.speech.tts.TextToSpeech(this) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                tts?.language = Locale("id", "ID")
                tts?.speak(s, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "smc")
            }
        }
    }

    private fun schedule(h: Int, m: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val pi = PendingIntent.getBroadcast(
            this, 123, Intent(this, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                Toast.makeText(this, "Izinkan alarm tepat, lalu tekan Pasang Pengingat lagi.", Toast.LENGTH_LONG).show()
                return
            }
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } catch (e: SecurityException) {
            Toast.makeText(this, "Izin alarm belum diberikan.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
